# File upload

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/mdPoYmY](https://codepen.io/havardob/pen/mdPoYmY).

Design by Paul van Oijen on Dribbble: https://dribbble.com/shots/3838821-Modals/attachments/869282 