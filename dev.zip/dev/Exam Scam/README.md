# nice-forms.css

A Pen created on CodePen.io. Original URL: [https://codepen.io/NielsVoogt/pen/eYBQpPR](https://codepen.io/NielsVoogt/pen/eYBQpPR).

A little helper library I made for styling input fields, check it out at https://nielsvoogt.github.io/nice-forms.css/