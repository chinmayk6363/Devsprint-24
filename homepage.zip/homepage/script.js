// Example: In a real-world scenario, you would fetch job listings from a server/database
const jobListingsData = [
    { title: 'Software Engineer', description: 'Exciting opportunity for a skilled software engineer...' },
    { title: 'Marketing Specialist', description: 'We are looking for a creative and experienced marketing specialist...' },
    // Add more job listings as needed
];

function searchJobs() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filteredJobs = jobListingsData.filter(job => job.title.toLowerCase().includes(searchTerm) || job.description.toLowerCase().includes(searchTerm));
    
    displayJobListings(filteredJobs);
}

function displayJobListings(jobs) {
    const jobListingsContainer = document.getElementById('jobListings');
    jobListingsContainer.innerHTML = '';

    jobs.forEach(job => {
        const jobCard = document.createElement('article');
        jobCard.classList.add('job-card');

        jobCard.innerHTML = `
            <h2>${job.title}</h2>
            <p>${job.description}</p>
            <button class="apply-button">Apply Now</button>
        `;
